#ifndef SENSORCOMS_H
#define SENSORCOMS_H

void SensorComThread();


#endif